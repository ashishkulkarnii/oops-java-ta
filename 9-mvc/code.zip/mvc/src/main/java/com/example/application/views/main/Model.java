package com.example.application.views.main;

import java.util.*;

class Employee {
    private int id;
    private String name;

    public Employee(int id, String name) {
    }

    public int getId() {
        return 0;
    }

    public String getName() {
        return "";
    }
}

public class Model {
    // all the employees stored by their id and name
    private List<Employee> emps = new ArrayList<Employee>();

    // manager id, and all the ids of the employees reporting to the manager
    private HashMap<Integer, List<Integer>> subordinates = new HashMap<Integer, List<Integer>>();

    public void addSubordinate(int id, int subId) {
    }

    public HashMap<Integer, List<Integer>> getSubordinates() {
        return new HashMap<Integer, List<Integer>>();
    }

    public void addEmployee(int id, String name) {
    }

    public List<Employee> getEmployees() {
        return new ArrayList<Employee>();
    }

    public List<Employee> getSubordinates(int id) {
        return new ArrayList<Employee>();
    }
}